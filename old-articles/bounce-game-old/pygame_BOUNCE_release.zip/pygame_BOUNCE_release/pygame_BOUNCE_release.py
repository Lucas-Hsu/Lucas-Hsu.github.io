'''
pygame_BOUNCE
by Yi-Wen (Lucas) Hsu
May 24, 2023

I have formatted and
slightly optimized the code,
also adding a few comments,
for this release version.
Nov. 16, 2025
'''

import os, sys, random, time, math
import pygame
import tkinter as tk
from tkinter import messagebox

Running = True
CONFIG_FILE = 'cfg.txt'

# Game loop
def runG():
    global Running
    pygame.init()
    start = time.time()
    currentTime = time.time()
    clock = pygame.time.Clock()
    # ensure highscore file exists
    try:
        f = open('HighScore.txt','r')
    except:
        f = open('HighScore.txt','w')
        f.write(str(0))
        f.close()
    else:
        f.close()

    # Read user and default configurations
    cfgDic, dk, dv = get_configs()

    # Initialize Game
    try:
        FrameRate = cfgDic[dk[0]]    
    except:
        os.remove('cfg.txt')
        print('config is broken!')
        pygame.quit()
        Running=False
    else:
        # What a convoluted way to store and initialize variables!
        # I should have used a JSON or something
        _i_ = 0
        FrameRate = cfgDic[dk[_i_]]
        _i_+=1
        sw = cfgDic[dk[_i_]]
        _i_+=1
        sh = cfgDic[dk[_i_]]
        _i_+=1
        fullscreen = cfgDic[dk[_i_]]
        _i_+=1
        ballsize = cfgDic[dk[_i_]]
        _i_+=1
        sqSize = cfgDic[dk[_i_]]
        _i_+=1
        ViFactor = (100-cfgDic[dk[_i_]])/-100
        _i_+=1
        ViFactor2 = (100-cfgDic[dk[_i_]])/-100
        _i_+=1
        hSpeed = cfgDic[dk[_i_]]
        _i_+=1
        vSpeed = cfgDic[dk[_i_]]
        _i_+=1
        SCORE = cfgDic[dk[_i_]]
        _i_+=1
        BoostCnt = cfgDic[dk[_i_]]
        _i_+=1
        BounceFactor = (100-cfgDic[dk[_i_]])/100
        _i_+=1
        FrictionFactor = (100-cfgDic[dk[_i_]])/100
        _i_+=1

    # Screen
    screensize = (sw,sh)
    if not fullscreen:
        screensize = width,height = math.floor(sw/1.2),math.floor(sh/1.2)
        screen = pygame.display.set_mode(screensize)
    elif fullscreen:
        screensize = width,height = sw,sh
        screen = pygame.display.set_mode(screensize,pygame.FULLSCREEN)
    else:
        screen = pygame.display.set_mode(screensize)

    # Paths
    abspath = os.getcwd()
    soundsPath = '/sounds/'
    imagesPath = './images/'

    # File Names
    BALL_NAME = imagesPath+'blue_square.png'
    BLOCK_NAME = imagesPath+'theBlock.png'
    BG_NAME = imagesPath+'theBackground.png'
    ICON_NAME = imagesPath+'icon.png'
    FONT_NAME = 'monaco'
    ballname = BALL_NAME
    
    sTime = time.time()

    # Sound_Effects
    # load a sound, default to empty sound if fail
    def load_sound(file_path):
        try:
            return pygame.mixer.Sound(file_path)
        except FileNotFoundError:
            return pygame.mixer.Sound("./defaults/NoSound.wav")
    # System Shock Sounds
    whoosh = load_sound(abspath+soundsPath+'0e1.wav')
    ding = load_sound(abspath+soundsPath+'0d6.wav')
    # System Shock 2 Sounds
    sq1 = load_sound(abspath+soundsPath+'bulftar1.wav')
    sq2 = load_sound(abspath+soundsPath+'bulftar2.wav')
    sq3 = load_sound(abspath+soundsPath+'bulftar3.wav')
    sq4 = load_sound(abspath+soundsPath+'hflesh1.wav')
    sq5 = load_sound(abspath+soundsPath+'hflesh2.wav')
    sq6 = load_sound(abspath+soundsPath+'hflesh3.wav')
    sq7 = load_sound(abspath+soundsPath+'HWREFLE4.wav')
    squishLst = [sq1,sq2,sq3,sq4,sq5,sq6,sq7]


    # Colors
    WHITE = (0,0,80) # LOL that's not white
    WHITEalpha = (255,255,255,2)
    PINKalpha = (250,220,220,1)
    REDalpha = (255,0,0,1)
    BLACKalpha = (0,0,0,1)
    color = BLACKalpha

    # UI Text
    font = pygame.font.SysFont(FONT_NAME,28)
    score_text = font.render("Score: "+str(SCORE),True, WHITE)
    countdown_text = font.render("Time Left:"+str(120-(currentTime-start)),True,WHITE)
    BoostCnt_text = font.render("Boosts: "+str(BoostCnt), True, WHITE)
    pygame.display.set_caption('\\\\pygame window// cpu - 100%, gpu - 100%')

    # Background
    background = pygame.image.load(BG_NAME).convert()
    background = pygame.transform.scale(background, screen.get_size())
    bgalpha = background.convert_alpha()
    bgalpha.fill(WHITEalpha,None,pygame.BLEND_RGBA_MULT)
    fade = pygame.Surface(screensize, pygame.SRCALPHA)
    fade.fill(color)

    # Icon
    pygame.display.set_icon(pygame.image.load(ICON_NAME))

    # Load and create shapes
    ball = pygame.image.load(abspath+'/'+ballname)
    br1 = ball.get_rect()
    ball = pygame.transform.scale(ball, (ballsize,(ballsize/int(br1[2])*br1[3])))
    ballrect = ball.get_rect()
    player = pygame.sprite.Sprite()
    player.rect = pygame.Rect(ballrect)

    block1 = pygame.sprite.Sprite()
    block2 = pygame.sprite.Sprite()

    blockimage = pygame.image.load(BLOCK_NAME)
    blockimage = pygame.transform.scale(blockimage,(sqSize, sqSize))
    blsize = blockimage.get_rect()

    block1.rect = pygame.Rect(blsize)
    block2.rect = pygame.Rect(blsize)

    lsize = blsize[2]
    rsize = blsize[3]

    # the .image is a 20x20 block
    block1.image = pygame.Surface((lsize,rsize))
    block2.image = pygame.Surface((lsize,rsize))

    block1.rect.x = random.randint(lsize, screensize[0]-rsize)
    block1.rect.y = random.randint(lsize, screensize[1]-rsize)

    block2.rect.x = random.randint(lsize, screensize[0]-rsize)
    block2.rect.y = random.randint(lsize, screensize[1]-rsize)

    # Input Keys/controls
    keelst = [pygame.K_q]
    k_pressed = [0]
    a =0
    mouseprev = True
    mouseprev2 = True

    # initialize
    prevBallRect = ballrect
    screen.blit(background,(0,0))
    # Actual Game Loop
    while Running:
        # Check Game Status
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                print('\n---User Exit---\nScore :',SCORE)
                pygame.quit()
                f = open('HighScore.txt','r')
                HiScore = int(f.read())
                if SCORE>HiScore:
                    f.close()
                    f = open('HighScore.txt','w')
                    f.write(str(SCORE))
                    f.close()
                    print('You Beat A HighScore!')
                Running=False
            if not Running:
                break
            if k_pressed[keelst.index(pygame.K_q)]:
                print('\n---User Exit---\nScore :',SCORE)
                pygame.quit()
                f = open('HighScore.txt','r')
                HiScore = int(f.read())
                if SCORE>HiScore:
                    f.close()
                    f = open('HighScore.txt','w')
                    f.write(str(SCORE))
                    f.close()
                    print('You Beat A HighScore!')
                Running=False
            if not Running:
                break
            if event.type == pygame.KEYDOWN:
                a =1
                if event.key in keelst:
                    for kee in range(len(keelst)):
                        if event.key == keelst[kee]:
                            k_pressed[kee] = 1
            if event.type == pygame.KEYUP:
                a = 0
                
        if not Running:
            break

        # Update UI text
        score_text = font.render("Score: "+str(SCORE), True, WHITE)
        countdown_text = font.render("Time Left:"+str(round(120-(currentTime-start),2)),True,WHITE)
        BoostCnt_text = font.render("Boosts: "+str(BoostCnt), True, WHITE)
        if not a:
            screen.blit(background,(0,0)) # clear/refresh screen
        # Wall collisions
        if ballrect[0] >= width-ballrect[2]: # RightWall
            hSpeed = abs(hSpeed)*-1*BounceFactor
            pygame.mixer.Sound.play(squishLst[random.randint(0,2)])
            if ballrect[0] >= width-ballrect[2]+10:
                hSpeed  = hSpeed
        if ballrect[0] <= 0:  # LeftWall
            hSpeed = abs(hSpeed)*BounceFactor
            pygame.mixer.Sound.play(squishLst[random.randint(0,2)])
            if ballrect[0] <= 0-11:
                hSpeed  = hSpeed
        if ballrect[1] <= 0: # Ceiling
            vSpeed = abs(vSpeed)*BounceFactor
            if (abs(hSpeed) >= 0.15 or abs(vSpeed)>= 6) and time.time()-sTime>0.2:
                pygame.mixer.Sound.play(squishLst[random.randint(6,6)])
                sTime = time.time()
            if ballrect[1] <= 0-80:
                vSpeed = vSpeed
        if ballrect[1] >= height-ballrect[3]: # Floor
            vSpeed = abs(vSpeed)*-1*BounceFactor
            hSpeed = hSpeed*FrictionFactor
            if (abs(hSpeed) >= 0.15 or abs(vSpeed) >= 6) and time.time()-sTime>0.2:
                pygame.mixer.Sound.play(squishLst[random.randint(3,4)])
                sTime = time.time()
            if ballrect[1] >= height-ballrect[3]+30:
                vSpeed = vSpeed
        else:
            vSpeed+=1 # gravity

        # launch/boost
        if pygame.mouse.get_pressed()[0] and mouseprev and BoostCnt:
            BoostCnt-=1
            mouseprev = False
            mpos = pygame.mouse.get_pos()
            dif = (((mpos[0]-ballrect[0])-ballrect[2]/2)/20,((mpos[1]-ballrect[1])-ballrect[3]/2)/20)
            hSpeed += ViFactor*hSpeed+dif[0]
            vSpeed += ViFactor*vSpeed+dif[1]
            pygame.mixer.Sound.play(whoosh)
            clock.tick(FrameRate)
        if not pygame.mouse.get_pressed()[0] and not pygame.mouse.get_pressed()[2]:
            mouseprev = True
        # Freezing
        if pygame.mouse.get_pressed()[2] and mouseprev2 and (mouseprev==True):
            hSpeed,vSpeed = (0,0)
            if pygame.mouse.get_pressed()[0] and mouseprev and BoostCnt:
                BoostCnt-=1
                mouseprev = False
                mouseprev2 = False
                mpos = pygame.mouse.get_pos()
                dif = (((mpos[0]-ballrect[0])-ballrect[2]/2)/20,((mpos[1]-ballrect[1])-ballrect[3]/2)/20)
                hSpeed += ViFactor2*hSpeed+dif[0]
                vSpeed += ViFactor2*vSpeed+dif[1]
                pygame.mixer.Sound.play(whoosh)
                clock.tick(FrameRate)
        if not pygame.mouse.get_pressed()[2]:
            mouseprev2 = True

        # move rects
        ballrect = ballrect.move(hSpeed,vSpeed)
        player.rect = ballrect.move(hSpeed,vSpeed)

        #Find Speed
        SPEED = round(math.sqrt(abs(hSpeed)**2+abs(vSpeed)**2))
        # Add points if collide with either block
        for block_other in [block1, block2]:
            if pygame.sprite.collide_rect(player, block_other):
                block_other.image.fill((255, 255, 255))
                screen.blit(block_other.image, block_other.rect.topleft)
                block_other.rect.x = random.randint(0, screensize[0]-lsize)
                block_other.rect.y = random.randint(0, screensize[1]-lsize)
                pygame.mixer.Sound.play(ding)
                block_other.image.fill((60, 200, 60))
                SCORE +=5*SPEED+5
                BoostCnt += 1
        
        # limit boosts
        if BoostCnt>10:
            BoostCnt=10
            
        # Stop jittering
        if abs(vSpeed)<0.00000001:
            vSpeed=0
        if abs(hSpeed)<0.00000001:
            hSpeed=0

        # Draw shapes
        screen.blit(bgalpha, (0,0))
        screen.blit(ball,ballrect)
        prevBallRect = ballrect
        screen.blit(blockimage,block1.rect)
        screen.blit(blockimage,block2.rect)        
        screen.blit(score_text, (10, 10))
        screen.blit(countdown_text, (width-280, 10))
        screen.blit(BoostCnt_text, (round(width/2-80), round(height-80)))
        # Display everything
        pygame.display.flip()

        # check gameover
        currentTime = time.time()
        if currentTime-start > 120:
            print('\nTime Is Up!!!\nScore :',SCORE)
            pygame.quit()
            f = open('HighScore.txt','r')
            HiScore = int(f.read())
            if SCORE>HiScore:
                f.close()
                f = open('HighScore.txt','w')
                f.write(str(SCORE))
                f.close()
                print('You Beat A HighScore!')
            Running=False
        if not Running:
            break
        # Check how long stopped moving
        if SPEED == 0 and restTime == '':
            restTime = time.time()
        if SPEED!=0:
            restTime = ''
        if type(restTime) != str:
            # quit game after run out of boosts and resting for 1 second
            if  not BoostCnt and time.time()-restTime>1 and not pygame.mouse.get_pressed()[2]:
                print('\nYou Ran Out Of Boosts!!!\nScore :',SCORE)
                pygame.quit()
                f = open('HighScore.txt','r')
                HiScore = int(f.read())
                if SCORE>HiScore:
                    f.close()
                    f = open('HighScore.txt','w')
                    f.write(str(SCORE))
                    f.close()
                    print('You Beat A HighScore!')
                Running=False
        if not Running:
            break
        clock.tick(FrameRate)

def get_configs():
    # See if config file exists
    try:
        f = open(CONFIG_FILE,'r')
    except:
        f = open(CONFIG_FILE,'w')
        f.write(str(0))
        f.close()
        configExists = 0
    else:
        f.close()
        configExists = 1
        cfg = open(CONFIG_FILE,'r')
        config = cfg.read().splitlines()
    # get defaults
    dk = open('./defaults/vars.txt','r').read().split(';')
    dv = open('./defaults/vals.txt','r').read().split(',')
    for i in range(len(dv)):
        dv[i] = int(dv[i])
    # build config dictionary
    cfgDic = {}
    if configExists:
        iterator = config
    else:
        iterator = dk
    for i in range(len(iterator)):
        if configExists:
            if ':' in iterator[i]:
                k,v = iterator[i].split(":")
                cfgDic[k] = int(v)
        else:
            cfgDic[dk[i]] = int(dv[i])
    # write config
    cfg = open(CONFIG_FILE,'w')
    config = '''Don't Type Spacebar!!!
    --------------------
    '''
    for i,k in zip(range(len(dk)),cfgDic.keys()):
        config+= '\n'+dk[i]+':'+str(cfgDic[k])
    cfg.write(config)
    cfg.close()
    return cfgDic, dk, dv
cfgDic, dk, dv = get_configs()

# Config Editor
root = tk.Tk()
root.title('Config Editor')
frame = tk.Frame(root)
frame.pack()

entries = {}

# Function to read the config file and create entry fields
def read_config():
    global entries
    # Clear existing fields
    for entry in entries.values():
        entry.destroy()
    entries.clear()
    # Open config file, read contents
    with open(CONFIG_FILE, 'r') as f:
        lines = f.readlines()
    # Create an entry field for each line that contains a ':'
    row = 0
    for line in lines:
        if ':' in line:
            key, value = line.strip().split(':')
            label = tk.Label(frame, text=key)
            label.grid(row=row, column=0)
            entry = tk.Entry(frame)
            entry.insert(0, value)
            entry.grid(row=row, column=1)
            entry.bind('<KeyRelease>', on_entry_change) # Bind entry field to call 'on_entry_change' when modified
            entries[key] = entry
            row += 1

# Function to save the changes to the config file
def save_config():
    global entries
    # Open config file, read contents
    with open(CONFIG_FILE, 'r') as f:
        lines = f.readlines()
    # Update values
    new_lines = []
    for line in lines:
        if ':' in line:
            key, value = line.strip().split(':')
            if key in entries:
                new_value = entries[key].get()
                new_line = f'{key}:{new_value}\n'
                new_lines.append(new_line)
            else:
                new_lines.append(line)
        else:
            new_lines.append(line)
    # Write to config
    with open(CONFIG_FILE, 'w') as f:
        f.writelines(new_lines)
    # Show save success
    save_button.config(text='Saved')
    
def on_entry_change(event):
    save_button.config(text='Save')

def play_game():
    global Running
    Running = True
    runG()

save_button = tk.Button(root, text='Save', command=save_config)
save_button.pack(side=tk.LEFT)
play_button = tk.Button(root, text='Play', command=play_game)
play_button.pack(side=tk.RIGHT)

read_config()
root.mainloop()
