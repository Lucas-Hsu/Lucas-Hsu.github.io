This is a readme so just read me

You can play the game by running pygame_BOUNCE_release.py in python
Make sure to have the required dependencies, tkinter and pygame.

You can change configuration in cfg.txt, preferrably in the config editor, not directly.
Remember to press "Save".

Credits:
Sounds Effects from System Shock and System Shock 2
Copy them into "./sounds/"
# System Shock 1
0e1.wav0d6.wav
# System Shock 2bulftar1.WAVbulftar2.WAVbulftar3.WAVhflesh1.wavhflesh2.wavhflesh3.wavHWREFLE4.WAV
If you don't have these files, can either play without sound, or put your own sounds and name them the same as that (or change the code.)

Do not edit anything in defaults!